class Pessoa:
    def __init__(self, nome, idade): #Inicialization of the variables from the class
        self.nome = nome
        self.idade = idade

    def saudacao(self):
        return f"O meu nome é {self.nome} e tenho {self.idade} anos." #Function from the class, thats gives us information about the person using the variables that we iniciated 

class Carro:
    def __init__(self, marca, modelo):  #Inicialization of the variable
        self.marca = marca
        self.modelo = modelo
        
    def informacao_do_carro(self):
        return f"Este é um {self.marca} {self.modelo}" #Function from the class, thats gives us information about the car using the variables that we iniciated 
    
class Professo:
    def __init__(self, nome, salario ):
        self.nome = nome
        self.salario = salario

    def informacao_do_professo(self):
        return f"O professor {self.nome} e recebe {self.salario}"