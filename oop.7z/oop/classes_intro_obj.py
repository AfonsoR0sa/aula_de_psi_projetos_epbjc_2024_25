from classes_intro_blueprints import Pessoa #in this line we are importing the class Pessoa from the file "classes_intro_blueprints"
from classes_intro_blueprints import Carro #in this line we are importing the class Carro from the file "classes_intro_blueprints"
from classes_intro_blueprints import Professo

pessoa = Pessoa("João", 16) #Instanciation of the class on this file
carro = Carro("Tesla", "Model3") #Instanciation of the class on this file
professo = Professo("José",  674)

print(pessoa.saudacao())    # In this line we are calling the function from the class "Pessoa" using the data that we put on the instanciation of it

print(carro.informacao_do_carro()) # In this line we are calling the function from the class "Carro" using the data that we put on the instanciation of it
print(professo.informacao_do_professo())